# GroupPlay

A website that tells a group what to play. One person answers four questions (how many people, phones, who is playing, what you have) and gets games that fit, with rules written to be read aloud. Includes host tools (timer, scoreboard, team divider, buzzer, random picker, musical-chairs referee) and phone-based games (Mafia narrator, Imposter, Heads Up, prompt decks).

Design constraints, in priority order:

1. **Works with no internet after the first visit.** Everything is precached by a service worker. Total first load is about 60 KB compressed.
2. **No build step, no dependencies.** Plain HTML, CSS and JavaScript. Edit a file, save, deploy. It even runs from a folder on disk (double-click `index.html`); only offline caching needs a real HTTPS host.
3. **Phone is a facilitator, not the game.** Most games in the catalogue need no phone at all.
4. **Nothing leaves the phone.** No accounts, no analytics, no server. Bookmarks, scores and game state live in localStorage.

## Folder layout

```
index.html            app shell (single page, hash routing)
css/app.css           all styles, light + dark
js/games.js           THE GAME DATABASE — the thing you will edit most (see SCHEMA.md)
js/decks.js           prompt decks: charades words, Bollywood titles, truth/dare, etc.
js/engine.js          recommendation filters + scoring, seeded random
js/store.js           localStorage wrapper
js/audio.js           synthesised sounds (no audio files)
js/ui.js              template helper, router, event delegation, toast, wake lock, speech
js/app.js             home, wizard, results, game page, browse, saved, tools index
js/tools.js           timer, random stop, scoreboard, teams, buzzer, picker
js/play.js            Mafia narrator, Imposter, Heads Up, prompt deck viewer
js/version.js         version string shown on the About page (written by release script)
sw.js                 service worker (cache-first precache; VERSION bumped per release)
manifest.webmanifest  PWA install metadata
icons/                app icons
_headers              Netlify / Cloudflare Pages cache headers
tools/validate-games.js   checks games.js + decks.js against the schema
tools/release.js          validates, then bumps the version in sw.js and js/version.js
SCHEMA.md             how to write a game entry
```

## Adding or editing games

1. Open `js/games.js`, copy an existing entry, change it. Field meanings and allowed values are in `SCHEMA.md`.
2. Run `node tools/validate-games.js`. Fix anything it reports. It also prints a coverage summary (how many games for elders, for 2–3 people, with no props, and so on) so you can see gaps.
3. Release (below).

Never change an existing game's `id`: bookmarks and "played tonight" are keyed on it.

## Releasing

```
node tools/release.js
```

This validates the content and bumps `VERSION` in `sw.js`. **If you skip this, phones that already have the site keep the old files forever** — the service worker only re-downloads when `sw.js` changes. Then deploy the whole folder.

### Netlify

Drag the folder onto app.netlify.com/drop, or connect the repository with no build command and publish directory `.` (the folder root). `_headers` is picked up automatically.

### Cloudflare Pages

Create a project, framework preset *None*, build command empty, output directory `/`. `_headers` is picked up automatically.

Both give HTTPS, which the service worker and the "install to home screen" prompt require.

## Testing locally

Any static server works. For example `python3 -m http.server 8080` in this folder, then open `http://localhost:8080`. Service workers are allowed on `localhost` without HTTPS.

`node tools/test-engine.js` runs the recommendation engine checks.

## Browser support

Modern Android Chrome and iOS Safari. Uses `localStorage`, Web Audio, Service Worker, optional Screen Wake Lock and Speech Synthesis (both degrade silently when missing). No polyfills.

## Later ideas (deliberately not built yet)

- Hindi / Telugu / Marathi text layer: keep English keys, add a translations file; the UI already keeps all text in JS.
- "Suggest a game" link to a form, then curated into `games.js` by hand.
- Real-time multiplayer (drawing, trivia) needs a relay server and data. Only worth it once people ask for it.
